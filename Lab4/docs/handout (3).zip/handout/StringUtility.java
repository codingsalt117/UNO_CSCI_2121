public class StringUtility {

    public static String reverse(String sentence) {
        // Delete the content in here and write your code in here.
        return "";
    }

    public static char maxOccuringCharacter(String sentence) throws IllegalArgumentException {
        // Delete this and write your code in here
        return 'a';
    }

    public static boolean isPalindrome(String input) {
        // Delete this and write your code in here

        return result;

    }
}
